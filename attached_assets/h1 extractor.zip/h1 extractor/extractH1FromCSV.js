const axios = require("axios");
const cheerio = require("cheerio");
const fs = require("fs");
const path = require("path");
const csv = require("csv-parser");

// File names
const inputCsvFile = "urls.csv"; // Input CSV with URLs
const outputCsvFile = "h1_results.csv"; // Output CSV with extracted H1s

// Function to read URLs from a CSV file
function readUrlsFromCsv(filePath) {
  return new Promise((resolve, reject) => {
    const urls = [];
    fs.createReadStream(filePath)
      .pipe(csv())
      .on("data", (row) => {
        if (row.URL) {
          urls.push(row.URL.trim());
        }
      })
      .on("end", () => {
        resolve(urls);
      })
      .on("error", reject);
  });
}

// Function to fetch H1 from a webpage
async function fetchH1(url) {
  try {
    const { data } = await axios.get(url, { timeout: 5000 });
    const $ = cheerio.load(data);
    const h1 = $("h1").first().text().trim();
    return h1 || "No H1 found";
  } catch (error) {
    return "Error fetching URL";
  }
}

// Function to extract H1s from URLs and save to CSV
async function extractH1FromUrls() {
  try {
    console.log("📥 Reading URLs from CSV...");
    const urls = await readUrlsFromCsv(inputCsvFile);
    
    if (urls.length === 0) {
      console.log("❌ No URLs found in the CSV file.");
      return;
    }

    const results = [["URL", "H1 Heading"]]; // CSV Header

    for (const url of urls) {
      const h1 = await fetchH1(url);
      results.push([url, h1]);
      console.log(`✅ Extracted: ${url} → ${h1}`);
    }

    // Convert array to CSV format
    const csvContent = results.map(row => row.map(value => `"${value}"`).join(",")).join("\n");

    // Save CSV with UTF-8 BOM encoding
    fs.writeFileSync(outputCsvFile, "\uFEFF" + csvContent, "utf8");

    console.log(`✅ Extraction completed. Results saved to: ${outputCsvFile}`);
  } catch (error) {
    console.error("❌ An error occurred:", error);
  }
}

// Run the script
extractH1FromUrls();
